import greenfoot.*;
import java.awt.Color;
/**
 * Write a description of class FinalScore here.
 * 
 * @author Tommy Wu
 * @version June 15, 2017
 */
public class FinalScore extends Actor
{
    public FinalScore(){
        String text = "Score: " + Overlay.getScore();
        GreenfootImage textImage = new GreenfootImage(text,100,Color.WHITE,new Color(0,0,0,0));
        setImage(textImage);
    }
    /**
     * Act - do whatever the FinalScore wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
}
