import greenfoot.*;

/**
 * This is the superclass that will declare the nature of each button
 * 
 * @author Jason Li & Felix Wang
 * @version June 14, 2017
 */
public class Button extends Actor
{
    protected int where;
    protected boolean mouseHovering;
    protected int timer = 0;
    protected int transparency;
    private GreenfootImage button1 = new GreenfootImage("start1.png");
    private GreenfootImage button2 = new GreenfootImage("start2.png");
    private GreenfootImage leader1 = new GreenfootImage("leader1.png");
    private GreenfootImage leader2 = new GreenfootImage("leader2.png");
    /**
     * Starts the correct world
     * @param whatToDo  1 = start, 2 = high scores, 3 = main menu, 4 = submit high score
     */
    public Button(int whatToDo){
        where = whatToDo;
    }
    protected void checkPress(){
        if(Greenfoot.mouseClicked(this)){
            if(where == 1){
                PlayWorld play = new PlayWorld();
                Greenfoot.setWorld(play);
                MusicBox.playGame();
            }
            else if(where == 2){
                MusicBox.playHighscore();
                HighScore high = new HighScore();
                Greenfoot.setWorld(high);
            }
            //Made by Felix
            else if(where == 3){
                Overlay.changeScore(0);
                Overlay.setHealth(100);
                Overlay.setBombs(3);
                MusicBox.playMenu();
                Title title = new Title();
                Greenfoot.setWorld(title);
            }
            else if(where == 4){
                HighScoreImage.writeToFile(Overlay.getScore());
            }
        }
        //Made by Felix
        if(where == 1){
            if (transparency < 255)
            {
                fade();
            } 
            if (!mouseHovering && Greenfoot.mouseMoved(this))
            {
                setImage(button2);
                mouseHovering = true;
            }
            if (mouseHovering && Greenfoot.mouseMoved(null) && !Greenfoot.mouseMoved(this))
            {
                setImage(button1);
                mouseHovering = false;
            }  
        }
        if(where == 2){
            if (!mouseHovering && Greenfoot.mouseMoved(this))
            {
                setImage(leader2);
                mouseHovering = true;
            }
            if (mouseHovering && Greenfoot.mouseMoved(null) && !Greenfoot.mouseMoved(this))
            {
                setImage(leader1);
                mouseHovering = false;
            } 
        }
    }
    //Made by Felix
    public void fade()
    {
        transparency = timer++;
        getImage().setTransparency(transparency);
    }
}
