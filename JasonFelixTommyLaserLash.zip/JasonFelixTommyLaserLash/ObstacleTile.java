import greenfoot.*;

/**
 * Write a description of class Tiles here.
 * 
 * @author Felix Wang
 * @version June 13, 2017
 */
public class ObstacleTile extends Actor
{
    int botLeftX, botLeftY;
    //Regular image
    private GreenfootImage transparent = new GreenfootImage(80,80);
    //Highlighted tile
    private GreenfootImage highlighted;
    boolean isHighlighted = false;
    
    BasicBlocker basic = new BasicBlocker();
    VerticalBlocker vertical = new VerticalBlocker();
    HorizontalBlocker horizontal = new HorizontalBlocker();
    Cherries cherries = new Cherries();
    
    int readyToMove = 70;
    /**
     * Constructs a tile based on its bottom left corner (relative to the world)
     * @param bLx    bottom left x coordinate
     * @param bR    bottom left y coordinate
     */
    public ObstacleTile(int bLX, int bLY){
        botLeftX = bLX;
        botLeftY = bLY;
        setImage(transparent);
    }
    public void act(){
        if(readyToMove > 0){
            readyToMove--;
        }
    }
    public int getMidX(){
        return botLeftX + 40;
    }
    public int getMidY(){
        return botLeftY + 40;
    }
    public void makeDefault(){
        setImage(transparent);
        isHighlighted = false;
    }
    public void makeA(){
        setImage(basic.getImage());
    }
    public void makeB(){
        setImage(vertical.getImage());
    }
    public void makeC(){
        setImage(horizontal.getImage());
    }
    public void makeD(){
        setImage(cherries.getImage());  
    }
    public boolean isReady(){
        if(readyToMove == 0){
            return true;
        }
        else{
            return false;
        }
    }
    public void resetReady(int time){
        readyToMove = time;
    }
}