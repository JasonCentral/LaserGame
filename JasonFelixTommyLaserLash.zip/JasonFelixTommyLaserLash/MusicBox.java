import greenfoot.*;

/**
 * Write a description of class MusicBox here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MusicBox extends Actor
{
    private static GreenfootSound currentSong = new GreenfootSound("gameSong.mp3");;
    /**
     * Act - do whatever the MusicBox wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }   
    public static void stopSong(){
        currentSong.stop();
    }
    public static void playMenu(){
        currentSong.stop();
        currentSong = new GreenfootSound("menuSong2.mp3");
        currentSong.playLoop();
    }
    public static void playOver(){
        currentSong.stop();
        currentSong = new GreenfootSound("menuSong.mp3");
        currentSong.playLoop();
    }
    public static void playGame(){
        currentSong.stop();
        currentSong = new GreenfootSound("gameSong.mp3");
        currentSong.playLoop();
    }
    public static void playHighscore(){
        currentSong.stop();
        currentSong = new GreenfootSound("highscoreSong.mp3");
        currentSong.playLoop();
    }
}
