import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
import java.util.ArrayList;
/**
 * The light that spawns when the player lets go of the mouse click
 * 
 * @author Jason Li
 * @version June 2017
 */
public class Beam extends Actor
{
    //default beam
    protected GreenfootImage beamImage;
    protected int fireDelay = 20;
    //For colour
    protected static int r = 255;
    protected static int g = 0;
    protected static int b = 0;
    /**
     * Constructs a basic beam with default delay at 20
     */
    private Beam(){
        beamImage = new GreenfootImage(81,81);
        Color beamColor = new Color(r,g,b);
        beamImage.setColor(beamColor);
        beamImage.fillRect(0,0,81,81);
        setImage(beamImage);
    }
    /**
     * Constructs a beam with user input fire delay
     */
    public Beam(int fDelay){
        this();
        fireDelay = fDelay;
    }
    /**
     * Act - do whatever the Beam wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    public void act() 
    {
        actMethods();
    }    
    //Decreases delay to 0, then disappears
    protected void checkDisappear(){
        if(fireDelay <= 0){
            getWorld().removeObject(this);
        }
        fireDelay --;        
    }
    protected void checkEnemy(){
        ArrayList<Enemies> enemyList = new ArrayList<Enemies>();
        enemyList = (ArrayList)getIntersectingObjects(Enemies.class);
        for(Enemies e: enemyList){
            e.damage(1);
        }
    }
    protected void actMethods(){
        checkEnemy();
        checkDisappear();
    }
    /**
     * Change color of the beam based on RGB
     * @param red   Red value
     * @param green Green value
     * @param blue  Blue value
     */
    public static void changeColor(int red, int green, int blue){
        r = red;
        g = green;
        b = blue;
    }
}
