import greenfoot.*;
import java.awt.Color;
/**
 * The building block of the game. These tiles can become highlighted, which provides the information needed
 * to tell the laser where to fire.
 * 
 * @author Jason Li
 * @version June 12, 2017
 */
public class Tile extends Actor
{
    int botLeftX, botLeftY;
    //Regular image
    private GreenfootImage transparent = new GreenfootImage(80,80);
    //Highlighted tile
    private GreenfootImage highlighted;
    private boolean isHighlighted = false;
    /**
     * Constructs a tile based on its bottom left corner (relative to the world)
     * @param bLx    bottom left x coordinate
     * @param bR    bottom left y coordinate
     */
    public Tile(int bLX, int bLY){
        botLeftX = bLX;
        botLeftY = bLY;
        setImage(transparent);
    }
    /**
     * Highlights the tile in green
     */
    public void highlight(){
        //Green highlight
        highlighted = new GreenfootImage(80,80);   
        highlighted.setColor(Color.GREEN);
        highlighted.fillRect(1,1,80,80);
        setImage(highlighted);
        isHighlighted = true;
    }
    /**
     * Turns the tile invisible again
     */
    public void makeDefault(){
        setImage(transparent);
        isHighlighted = false;
    }
    /**
     * Returns the mid x coordinate of this tile
     * @return  The mid x coordinate
     */
    public int getMidX(){
        return botLeftX + 40;
    }
        /**
     * Returns the mid y coordinate of this tile
     * @return  The mid y coordinate
     */
    public int getMidY(){
        return botLeftY + 40;
    }
    /**
     * Returns whether or not this tile is highlighted
     * @return  True for it is highlighted, false for it is not highlighted
     */
    public boolean isHighlighted(){
        return isHighlighted;
    }
}
