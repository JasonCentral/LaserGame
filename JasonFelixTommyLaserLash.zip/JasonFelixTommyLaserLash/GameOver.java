import greenfoot.*;

/**
 * Write a description of class GameOver here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class GameOver extends World
{
    //Main menu button
    MainMenu menu = new MainMenu();
    Submit submit = new Submit();
    FinalScore score = new FinalScore();
    /**
     * Constructor for objects of class GameOver.
     * 
     */
    public GameOver()
    {    
        super(960, 640, 1); 
        addObject(menu,960/2,500);
        addObject(submit,960/2,200);
        addObject(score,960/2,100);
    }
}
