import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.Color;
/**
 * Write a description of class Overlay here.
 * 
 * @author Jason Li
 * @version June 13, 2017
 */
public class Overlay extends Actor
{
    int type;
    private static int score = 0;
    private static int health = 100;
    private static int bombs = 3;
    private GreenfootImage scoreBar = new GreenfootImage(100,20);
    /**
     * @param type  Type 1: score, type 2: health 
     */
    public Overlay(int type){
        this.type = type;
        update();
    }
    /**
     * Act - do whatever the Overlay wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        update();
    }    
    public static void changeScore(int newScore){
        score = newScore;
    }
    public static void addScore(int scoreNum){
        score += scoreNum;
    }
    public static int getScore(){
        return score;
    }
    public static void decreaseHealth(int decreaseNum){
        if(health > decreaseNum){
            health -= decreaseNum;
        }
        else{
            health = 0;
            //sends to game over screen
            MusicBox.playOver();
            GameOver over = new GameOver();
            Greenfoot.setWorld(over);
        }
    }
    public static void increaseHealth(int increaseNum){
        health += increaseNum;
    }
    public static void setHealth(int newHealth){
        health = newHealth;
    }
    public static void setBombs(int num){
        bombs = num;
    }
    public static int getBombs(){
        return bombs;
    }
    public void update(){
        GreenfootImage temp = new GreenfootImage(150,25);
        if(type != 3){
            temp = new GreenfootImage(150,25);
            temp.setColor(new Color(0,180,180));
            temp.fill();
            temp.setColor(Color.WHITE);
            temp.drawRect(0,0,149,24);
        }
        if(type == 3){
            temp = new GreenfootImage(251,25);
            temp.setColor(new Color(0,180,180));
            temp.fill();
            temp.setColor(Color.WHITE);
            temp.drawRect(0,0,250,24);
        }
        String text = "PLACEHOLDER";
        //Spawn rate controls
        if(type == 1){
            text = "POINTS: " + score;
        }
        else if(type == 2){
            text = "HEALTH: " + health;
        }
        else if(type == 3){
            text = "BOMBS: " + bombs + "(PRESS SPACE)";
        }
        GreenfootImage textImage = new GreenfootImage(text,25,Color.BLACK,new Color(0,0,0,0));
        temp.drawImage(textImage,4,0);
        scoreBar = new GreenfootImage(temp);
        setImage(scoreBar);
    }
}
