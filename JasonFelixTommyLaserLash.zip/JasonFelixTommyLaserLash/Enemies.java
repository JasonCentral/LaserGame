import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Enemies here.
 * 
 * @author Tommy Wu 
 * @version June 15, 2017
 */
public class Enemies extends Actor
{
    protected int move = 0;
    protected int health = 0;
    protected int actCounter = 0;
    FWJLStatusBar healthBar;
    
    protected void addedToWorld(World world)
    {
       healthBar.addToWorld();
       healthBar.hideBar();
    }
    
    public Enemies(int h)
    {
       healthBar = new FWJLStatusBar(h,this);
    }
    
    /**
     * set the speeds for the enemies
     * 
     * @param integer for how fast
     */
    public void setSpeed(int n)
    {
        move = n;
    }

    /**
     * the movment of the enemies
     * 
     * @param mob actor for which the moving is applied to
     */
        public void movement(Actor mob)
    {
        mob.setLocation(mob.getX(), mob.getY() + move);
        
        actCounter++;
        if (actCounter < 50)
        {
            mob.setLocation(mob.getX() + move,mob.getY());
        }
        else if (actCounter > 50)
        {
            mob.setLocation(mob.getX() - move,mob.getY());
        }
        if(actCounter == 100)
        {
            actCounter = 0;
        }
        atEdge(mob);
    }
    
    /**
     * checks if the actor has reached the edge 
     * 
     * @param x actor to check
     */
    public void atEdge(Actor x)
    {
        if (x.getY() > getWorld().getHeight()- 81)
        {
            Overlay.decreaseHealth(1);
            getWorld().removeObject(x);
        }
    }
    
    public void damage(int d)
    {
        healthBar.showBar();
        if(health > d)
        {
            health = health - d;
            healthBar.decrease(d);
        }
        else
        {
            Overlay.addScore(1);
            getWorld().removeObject(this);
        }
    }
}