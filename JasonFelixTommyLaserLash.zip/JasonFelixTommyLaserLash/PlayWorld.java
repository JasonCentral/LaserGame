import greenfoot.*;

/**
 * Welcome to laser lash, where you must use your mouse to form a path to call down a laser which will damage all
 * in said path! However, you must dodge the obstacles or your beam of destruction will be cut short. Get the 
 * highest score you can with the 100 lives given. The game gets progressively harder, introducing new enemies 
 * as it goes on. You can you up to three bombs, which spawns a gigantic red laser which will clear the screen.
 * 
 * Enemy, some background images,and button images found by Tommy
 * Obstacle images, Intro animation, button effects (& some button images), game logo done by Felix
 * Some background and misc. images found by Jason
 * 
 * @author Jason Li, Felix Wang, and Tommy Wu
 * @version June 15, 2017
 */
public class PlayWorld extends World
{
    private static Grid mainGrid = new Grid();
    private static Overlay score = new Overlay(1);
    private static Overlay health = new Overlay(2);
    private static Overlay bombs = new Overlay(3);
    
    protected int spawn = 0;
    protected int spawnPoint = 0;
    protected int spawnRate = 500;
    protected int level = 0;
    protected int difficulty = 0;
    
    protected static ObstacleGrid mainObstacleGrid = new ObstacleGrid();
    public void act(){
        spawn();
    }
    /**
     * Constructor for objects of class TestWorld.
     * 
     */
    public PlayWorld()
    {    
        super(960, 640, 1); 
        //Adds grid
        addObject(mainGrid,getWidth()/2,getHeight()/2);
        addObject(new Laser1(),960/2,650);
        addObject(score,800,600);
        addObject(health,150,580);
        addObject(bombs,150,605);
        //Setting up the obstacle grid
        addObject(mainObstacleGrid,getWidth()/2,getHeight()/2);
        mainObstacleGrid.setMap(ObstacleWorld.setFields());
    }
    public static Grid getGrid(){
        return mainGrid;
    }
    //Tommy's Method
    /**
     * Spawns enemies
     */
    public void spawn(){
        spawn = Greenfoot.getRandomNumber(spawnRate);
        spawnPoint = Greenfoot.getRandomNumber(960);
        if(spawn == 1 || spawn == 6 || (difficulty < 2 && spawn == 7))
        {
            addObject(new Basic(10),spawnPoint, 1);
        }
        else if (spawn == 2 && difficulty > 0)
        {
            addObject(new Strmob(40), spawnPoint, 1);
        }
        else if (spawn == 3 && difficulty > 2)
        {
            addObject (new Jumper(20), spawnPoint, 1);
        }
        else if (spawn == 4 && difficulty > 4)
        {
            addObject (new Charger(30), spawnPoint, 1);
        }
        else if(spawn == 5 && difficulty > 6){
            addObject(new Invis(20),spawnPoint,1);
        }
        level++;
        if (level > 900)
        {
            spawnRate = spawnRate - 20;
            level = 0;
            difficulty ++;
        }
        else if (spawnRate < 80)
        {
            spawnRate = 80;
        }
    }
}
