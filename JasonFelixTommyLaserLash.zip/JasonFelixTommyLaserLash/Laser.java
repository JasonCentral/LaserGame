import greenfoot.*;
import java.util.ArrayList;
/**
 * This is the laser class, where mouse action is checked to see what will be highlighted and and how the laser
 * will be fired.
 * 
 * @author Jason Li
 * @version (a version number or a date)
 */
public abstract class Laser extends Actor
{
    MouseInfo mouse;
    //Have a type of beam selected
    protected int beamSelected = 1;
    //Array list to hold highlighted tiles
    protected ArrayList<Tile> tileList = new ArrayList<Tile>();
    protected int maxSquares = 10;
    protected int bombCooldown = 0;
    /**
     * Constructs laser with defaults
     */
    public Laser(){
        
    }
    /**
     * Constructs laser based on beam
     */
    public Laser(int b){
        beamSelected = b;
    }
    /**
     * Act - do whatever the Laser wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        actMethods();
    }    
    /**
     * Put all act methods here to easily deal with inheritance
     */
    protected void actMethods(){
        check();
        bombCheck();
    }
    protected void check(){
        if(leftDown()){
            //If it's the first one, you can click anywhere on the first rank
            if(tileList.isEmpty()){
                Tile mouseGrid = getMouseGrid();
                if(mouseGrid.getMidY() == 600){
                    mouseGrid.highlight();
                    Grid.setLastHighlighted(mouseGrid);
                    //Add to array list
                    tileList.add(mouseGrid);
                    PlayWorld.getGrid().showGrid();
                }
            }
            //If it's not, only allow sides to prevent diagonal and skipping (TOO MUCH TIME BETWEEN ACTS!!)
            //And also only if the number already highlighted is less than max
            //And also only if the last tile is one next to it
            else if(tileList.size() < maxSquares){
                Tile mouseGrid = getMouseGrid();
                if(Grid.isSideLastHighlighted(mouseGrid)){
                    //This if statement triggers if it is the first time the mouse is held on this tile
                    if(!mouseGrid.isHighlighted()){
                        //Makes this the last highlighted tile
                        Grid.setLastHighlighted(mouseGrid);
                        //Add to array list
                        tileList.add(mouseGrid);
                    }
                    mouseGrid.highlight();
                    PlayWorld.getGrid().showGrid();
                }
            }
        }
        if(Greenfoot.mouseClicked(null)){
            //Fires the actual beam (which just spawns tile sized beam actors on every tile)
            fireBeam();
            //Clears highlights
            Grid.clearTiles();
            //Hides the grid so the player can see the beam go!
            PlayWorld.getGrid().hideGrid();
        }
    }
    /**
     * Returns the grid that the mouse is currently on
     */
    protected Tile getMouseGrid(){
        mouse = Greenfoot.getMouseInfo();
        //Set to some insignificant number that won't affect game if mouse info returns invalid
        int mouseX = -1;
        int mouseY = -1;
        //If mouse info is valid
        if(mouse!=null) {
            mouseX = mouse.getX();
            mouseY = mouse.getY();
        }
        //if mouse is within the field
        if(mouseX > 0 && mouseX < 960 && mouseY > 0 && mouseY < 640){
            return Grid.getTile(mouseX/80,mouseY/80);
        }
        else{
            //Returns a dud if mouse is not within the field (or if mouse info didn't return useful)
            return new Tile(1000,1000);
        }
    }
    //Returns whether the left mouse button is down
    protected boolean leftDown(){
        mouse = Greenfoot.getMouseInfo();
        int down = -1;
        if(mouse!=null){
            down = mouse.getButton();
        }
        //If left button pressed
        if(down == 1){
            return true;
        }
        else{
            return false;
        }
    }
    protected void bombCheck(){
        if(bombCooldown > 0){
            bombCooldown --;
        }
        if(Greenfoot.isKeyDown("space")){
            if(bombCooldown == 0){
                //This if statement triggers the bomb
                if(Overlay.getBombs() > 0){
                    Greenfoot.playSound("laser.wav");
                    for(int x=0;x<12;x++){
                        for(int y=0;y<8;y++){
                            fire(Grid.getTile(x,y));
                        }
                    }
                    bombCooldown = 100;
                    Overlay.setBombs(Overlay.getBombs()-1);
                }
            }
        }
    }
    /**
     * Changes the max amount of squares the user can draw
     * @param max   new max amount
     */
    public void changeMax(int max){
        if(max>=1){
            maxSquares = max;
        }
    }
    /**
     * Spawns the beam on the tile
     */
    public void fire(Tile t){
        getWorld().addObject(new Beam(20), t.getX(), t.getY());
        //Note: disappears in beam class
    }
    /**
    * Fires the entire beam. If an obstacle is in the way, the beam will be cut short
    */
    public void fireBeam(){
        if(!tileList.isEmpty()){
            Greenfoot.playSound("laser.wav");
        }
        for(Tile t : tileList){
            //If there is not an obstacle on this tile, fire laser on this spot
            if(!Grid.isObstacle(t)){
                fire(t);
            }
            //If there is an obstacle stop firing on tiles on array list after
            //Arraylist is dynamically formed in order, so it will stop all the ones after
            else{
                break;
            }
        }
        //After firing, clears array list for next time
        tileList.clear();
    }
    /**
     * Changes the color of the beam
     * @param r Red value (0-255)
     * @param g Green value (0-255)
     * @param b Blue value (0-255)
     */
    public void changeBeamColor(int r, int g, int b){
        Beam.changeColor(r,g,b);
    }
    
}
