import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Charger here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Charger extends Enemies
{
    private int pauseCounter = 0;

    public Charger(int h)
    {
        super(h);
        health = h;
        setSpeed(1);
    }

    public void act() 
    {
        if(this.getY() < 250)
        {
            movement(this);
        }
        else if (this.getY() >= 250)
        {
            pauseCounter++;
            if (pauseCounter > 30)
            {
                setLocation(this.getX(),this.getY() + 8);
                atEdge(this);
            }
        }
    }

    public void addedToWorld(World world){
        super.addedToWorld(getWorld());
        healthBar.update(health,true);
    }
}