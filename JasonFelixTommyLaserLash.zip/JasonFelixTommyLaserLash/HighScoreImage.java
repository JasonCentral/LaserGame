import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.NoSuchElementException;
import java.awt.Color;
import java.util.Arrays;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.IOException;
/**
 * This class is responsible for generating the image of high scores that will be put into the 
 * high score world. It also provides the method to attempt to write another high score to the list.
 * @author Jason Li
 * @version June 15, 2017
 */
public class HighScoreImage extends Actor
{
    private static Scanner scoreScan;
    public HighScoreImage(){
        int[] scoreArray = readFile();
        //Sort the array
        Arrays.sort(scoreArray);
        //Display scores (in reverse order)
        GreenfootImage scoreImage = new GreenfootImage(960,640);
        int length = scoreArray.length;
        String topText = "HIGH SCORES";
        GreenfootImage topTextImage = new GreenfootImage(topText,60,Color.BLACK,new Color(0,0,0,0));
        scoreImage.drawImage(topTextImage,330,0);
        for(int i = length-1;i>=0;i--){
            String text = Integer.toString(length-i) + ". " + Integer.toString(scoreArray[i]);
            
            GreenfootImage textImage = new GreenfootImage(text,50,Color.BLACK,new Color(0,0,0,0));
            scoreImage.drawImage(textImage,4,60+60*(length-i-1));
        }
        setImage(scoreImage);
    }
    /**
     * Will display the top 10 scores
     */
    private static int[] readFile(){
        String file = "score.txt";
        boolean fileExists = true;
        //tries to read the file
        try{
            scoreScan = new Scanner(new File(file));
        }
        catch(FileNotFoundException e){
            System.out.println("No File");
            fileExists = false;
        }
        //Initialize variables
        int[] array;
        int numLines = 0;
        boolean moreLines = true;
        //Finds how many lines there are
        while(moreLines && fileExists){
            try{
                scoreScan.nextInt();
                numLines ++;
            }
            //If there are no more lines, set variable to false, end loop
            catch(NoSuchElementException e){
                moreLines = false;
            }
        }
        //Reset the scanner
        try{
            scoreScan = new Scanner(new File(file));
        }
        catch(FileNotFoundException e){
            //Already caught previously
        }
        //Read the file again, but this time assign the int values to an array
        array = new int[numLines];
        for(int i = 0;i<numLines;i++){
            array[i] = scoreScan.nextInt();
        }
        //return the array
        return array;
    }
    /**
     * Writes high score the score file. If the score is not within the top 10, nothing will happen.
     * If it is within the top 10, it will replace the worst score.
     * @param score The score to write
     */
    public static void writeToFile(int score){
        int[] scores = readFile();
        Arrays.sort(scores);
        if(scores.length < 10){
            //if not enough scores, make another array with one more
            int[] temp = new int[scores.length];
            for(int i = 0; i < scores.length; i++){
                temp[i] = scores[i];
            }
            scores = new int[temp.length+1];
            for(int i = 0; i < temp.length; i++){
                scores[i] = temp[i];
            }
            scores[scores.length - 1] = score;
        }
        else{
            if(score > scores[0]){
                scores[0] = score;
            }
        }
        try{
            PrintWriter printer = new PrintWriter(new FileWriter("score.txt"));
            printer.print("");
            //PrintWriter printer2 = new PrintWriter(new FileWriter("score.txt",true));
            for(int i = 0; i < scores.length; i++){
                printer.println(Integer.toString(scores[i]));
            }
            printer.close();
        }
        catch(IOException e){
        }
        Overlay.changeScore(0);
    }
}
