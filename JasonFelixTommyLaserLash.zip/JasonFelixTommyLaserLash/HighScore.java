import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Write a description of class HighScore here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class HighScore extends World
{
    HighScoreImage image = new HighScoreImage();
    MainMenu menu = new MainMenu();
    /**
     * Constructor for objects of class HighScore.
     * 
     */
    public HighScore()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(960, 640, 1); 
        addObject(image,960/2,640/2);
        addObject(menu,800,500);
    }
}
