import greenfoot.*;  // This is the title screen

/**
 * Write a description of class Title here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Title extends World
{
    private Play play;
    private Scores scores;
    private Logo logo;
    /**
     * Constructor for objects of class Title.
     * 
     */
    public Title()
    {   
        super(960, 640, 1); 
        play = new Play();
        scores = new Scores();
        logo = new Logo();
        addObject(play, 960/2,250);
        addObject(scores, 960/2,450);
        addObject(logo,960/2,100);
    }
}
